package assetlink.ObjectRepo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginpageObj {

	WebDriver driver;
	
	@FindBy(id="idp-discovery-username")
	WebElement Username;
			
	@FindBy(id="idp-discovery-submit")
	WebElement Nextbutton;
	
	@FindBy(name="password")
	WebElement Password;
	
	@FindBy(xpath="//*[@id=\"form7\"]/div[2]/input")
	WebElement submitButton;


public LoginpageObj(WebDriver driver) {
	// TODO Auto-generated constructor stub
	this.driver=driver;
	PageFactory.initElements(driver, this);

}


public void next()
{
	 Nextbutton.click();
}

public void password(String password)
{
	Password.sendKeys(password);
}

public void submit()
{
	submitButton.click();
}

public void username(String username) {
	// TODO Auto-generated method stub
	Username.sendKeys(username);
	
}


}
