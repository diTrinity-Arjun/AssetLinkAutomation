 package assetlink.ObjectRepo;
import java.io.File;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.apache.commons.*;
import ch.qos.logback.core.util.FileUtil;
	
public class EquipmentNeedObj {
		WebDriver driver;
		@FindBy(id="mxui_widget_SidebarToggleButton_0")
		WebElement SideMenu;
				
		@FindBy(xpath="//*[@id=\"mxui_widget_HorizontalScrollContainer_0\"]/div[1]/div/div[2]/div/ul/li[4]/a")
		WebElement EquipmentNeed;
		
		@FindBy(id="mxui_widget_ControlBarButton_1")
		WebElement NewEquipment;
		
		@FindBy(xpath="//*[@id=\"92.EquipmentNeed.Needs_NewEdit.referenceSelector5.30_atg_95\"]")
		WebElement SelectCompany;
		
	
		
		@FindBy(xpath="//*[@id=\"92.EquipmentNeed.Needs_NewEdit.referenceSelector4.36_atg_192\"]")
		WebElement Location;
		
		@FindBy(id="92.EquipmentNeed.Needs_NewEdit.textBox1.41_atg_195")
		WebElement title;
		
		@FindBy(xpath="//*[@id=\"92.EquipmentNeed.Needs_NewEdit.referenceSelector1.47_atg_198\"]")
		WebElement make;
		
		@FindBy(xpath="//*[@id=\"mxui_widget_ReferenceSelector_1\"]/select")
		WebElement Model;
		
		@FindBy(id="92.EquipmentNeed.Needs_NewEdit.textArea1.58_atg_202")
		WebElement Description;
		
		@FindBy(xpath="//*[@id=\"mxui_widget_DataView_8\"]/div[1]/div[2]/div/div[7]/div[2]/div/div/button")
		WebElement Calender;
		
		@FindBy(xpath="//*[@id=\"mxui_widget_DataView_8\"]/div[2]/button[1]")
		WebElement Save;
		
		public EquipmentNeedObj (WebDriver driver) {
			// TODO Auto-generated constructor stub
			this.driver=driver;
			PageFactory.initElements(driver, this);
			}

		
		public void selectLocation()
		{
			Location.click();
		}
		public void EnterTitle(String Title)
		{
			title.sendKeys(Title);
		}
		public void selectMake()
		{
			make.click();
		}
		public void SelectModel()
		{
			 Model.click();
		}
		public void Description(String des)
		{
			Description.sendKeys(des); 
		}			
		public void SelectDate()
		{
			Calender.click();
		
	
			
		
		}
		public void Save()
		{
			 Save.click();
		}
	
		public void Togglemenu()
		{
			 SideMenu.click();
		}
	
		public void EquipmentMenu()
		{
			EquipmentNeed.clear();
		}
	
		public void CreateNewEquipment()
		{
			NewEquipment.click();
		}
		public void selectCompany(String Company) {
			// TODO Auto-generated method stub
			SelectCompany.sendKeys(Company);
			
		}
	
		public void selectDate(String month_year, String select_day) throws InterruptedException
		{ 
			List<WebElement> elements = driver.findElements(By.xpath("//div[@class='ui-datepicker-title']/span[1]"));
			
			for (int i=0; i<elements.size();i++)
			{
			System.out.println(elements.get(i).getText());
			
			//Selecting the month
			if(elements.get(i).getText().equals(month_year))
			{ 
			
			//Selecting the date 
			List<WebElement> days = driver.findElements(By.xpath("//div[@class='ui-datepicker-inline ui-datepicker ui-widget ui-widget-content ui-helper-clearfix ui-corner-all ui-datepicker-multi ui-datepicker-multi-2']/div[2]/table/tbody/tr/td/a"));
			
			for (WebElement d:days)
			{ 
			System.out.println(d.getText());
			if(d.getText().equals(select_day))
			{
			d.click();
			Thread.sleep(10000);
			return;
			}
			}		
			}
		
			}
		}
		
		public static void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
			//Convert web driver object to TakeScreenshot
			TakesScreenshot scrShot =((TakesScreenshot)webdriver);
			//Call getScreenshotAs method to create image file
			File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
			//Move image file to new destination
			File DestFile=new File(fileWithPath);
	
			}
		
		public void seletionMethod(String value) throws InterruptedException
		{
			WebElement solutions_dropdown = driver.findElement(By.id("solutions-menu-dropdown"));
			Select solutions = new Select(solutions_dropdown);
			solutions.selectByValue("4000");
			Thread.sleep(3000);
			WebElement solutions_d = driver.findElement(By.id(value));
			solutions_d.isSelected();
					
		}

}