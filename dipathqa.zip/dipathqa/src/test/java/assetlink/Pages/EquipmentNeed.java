package assetlink.Pages;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import assetlink.ObjectRepo.EquipmentNeedObj;

public class EquipmentNeed {
	 EquipmentNeedObj equipment;
	 Loginpage login;

 @BeforeClass
public void  CallLogin() throws FileNotFoundException, IOException, ParseException
{
		 login.Login();
}
	 
	@Test 
	public void EquipmentNeedCreation() throws FileNotFoundException, IOException, ParseException
	{
		String title,Des,company;
		 JSONParser parser1=new JSONParser();
		 Object obj1 = parser1.parse(new FileReader("C:\\Users\\Lenovo\\git\\dipathqa\\JsonFiles\\equipmentData.json"));
		 JSONObject jsonObject = (JSONObject) obj1;
		 title = (String) jsonObject.get("Title");
		 company = (String) jsonObject.get("CompanyName");
		 Des=(String) jsonObject.get("description");
		equipment.Togglemenu();
		equipment.EquipmentMenu();
		equipment.CreateNewEquipment();
		equipment.selectCompany(company);
		equipment.selectLocation();
		equipment.EnterTitle(title);
		equipment.selectMake();
		equipment.SelectModel();
		equipment.Description(Des);
		equipment.SelectDate();
		equipment.Save();
		
		
		
	}

	
}
