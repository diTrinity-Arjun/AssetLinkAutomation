package assetlink.Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import assetlink.ObjectRepo.EquipmentNeedObj;
import assetlink.ObjectRepo.LoginpageObj;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

	public class Loginpage {
		 private WebDriver driver;
		 JSONParser parser=new JSONParser();
		 LoginpageObj login;
		 EquipmentNeedObj equipment;
		 
		
@BeforeClass
public void BeforeClass( ) throws FileNotFoundException, IOException, ParseException
		{	
	         Object obj = parser.parse(new FileReader("C:\\Users\\Lenovo\\git\\dipathqa\\JsonFiles\\TestDataConfig.json"));
	         JSONObject jsonObject = (JSONObject) obj;
	         String url,Dpath;
			 url = (String) jsonObject.get("testUrl"); 
			 Dpath=(String) jsonObject.get("path");
			 System.setProperty("webdriver.chrome.driver",Dpath);
			 driver=new ChromeDriver();
			 login= new LoginpageObj(driver);
			 driver.manage().window().maximize();
			 driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			 driver.get(url);
		 }
		 
	@Test 
public void Login( ) throws FileNotFoundException, IOException, ParseException
		{					
			 String username,Password;
			 JSONParser parser=new JSONParser();
			 Object obj = parser.parse(new FileReader("C:\\Users\\Lenovo\\git\\dipathqa\\JsonFiles\\TestDataConfig.json"));
			 JSONObject jsonObject1 = (JSONObject) obj;
			 username = (String) jsonObject1.get("username");
			 Password = (String) jsonObject1.get("password");
			 login.username(username);
			 login.next();
			 login.password(Password);
			 login.submit();
			 
			 String title,Des,company;
			 JSONParser parser1=new JSONParser();
			 Object obj1 = parser1.parse(new FileReader("C:\\Users\\Lenovo\\git\\dipathqa\\JsonFiles\\equipmentData.json"));
			 JSONObject jsonObject = (JSONObject) obj1;
			 title = (String) jsonObject.get("Title");
			 company = (String) jsonObject.get("CompanyName");
			 Des=(String) jsonObject.get("description");
			equipment.Togglemenu();
			equipment.EquipmentMenu();
			equipment.CreateNewEquipment();
			equipment.selectCompany(company);
			equipment.selectLocation();
			equipment.EnterTitle(title);
			equipment.selectMake();
			equipment.SelectModel();
			equipment.Description(Des);
			equipment.SelectDate();
			equipment.Save();
			
 
			
		}

}		   
	

	
	


