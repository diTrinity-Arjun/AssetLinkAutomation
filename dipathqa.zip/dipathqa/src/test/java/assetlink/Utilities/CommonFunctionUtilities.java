package assetlink.Utilities;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

public class CommonFunctionUtilities {

	 @BeforeTest 
	 public void Testdata() throws FileNotFoundException, IOException, ParseException
	    {
	
		WebDriver driver;
	    String url,username,Password;
	    
	    JSONParser parser=new JSONParser();

	   
	        Object obj = parser.parse(new FileReader("C:\\Users\\Lenovo\\git\\dipathqa\\JsonFiles\\TestDataConfig.json"));

	        JSONObject jsonObject = (JSONObject) obj; 
	        url = (String) jsonObject.get("testUrl"); 
	        username = (String) jsonObject.get("username");
	        Password = (String) jsonObject.get("Password");
	        System.out.println(url);
	        System.out.println(username);
	        System.out.println(Password);
	        driver = new ChromeDriver(); 
	        driver.get(url);
	    }

	
}
